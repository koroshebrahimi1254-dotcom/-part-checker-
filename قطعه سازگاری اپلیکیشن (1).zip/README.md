
  # قطعه سازگاری اپلیکیشن

  This is a code bundle for قطعه سازگاری اپلیکیشن. The original project is available at https://www.figma.com/design/qY5Us3mLoEtg0kwE0QrmEP/%D9%82%D8%B7%D8%B9%D9%87-%D8%B3%D8%A7%D8%B2%DA%AF%D8%A7%D8%B1%DB%8C-%D8%A7%D9%BE%D9%84%DB%8C%DA%A9%DB%8C%D8%B4%D9%86.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  