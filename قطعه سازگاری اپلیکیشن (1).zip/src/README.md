# پارت چکر - بررسی سازگاری قطعات کامپیوتر

🔧 اپلیکیشن هوشمند برای بررسی سازگاری قطعات کامپیوتر و دریافت پیشنهادات تخصصی

## ✨ امکانات

- 🛠️ **بررسی سازگاری هوشمند** - تشخیص خودکار مشکلات سازگاری
- 📱 **PWA** - قابل نصب روی موبایل و دسکتاپ
- 🎯 **پیشنهاد قطعه** - دریافت پیشنهاد از جامعه کاربری
- 🔐 **سیستم کاربری** - ثبت نام و ورود
- 🌙 **رابط کاربری جذاب** - طراحی مدرن و ریسپانسیو
- 🚀 **سرعت بالا** - بهینه‌سازی شده برای عملکرد

## 🚀 نصب و راه‌اندازی

### نصب Dependencies
```bash
npm install
```

### اجرای حالت Development
```bash
npm start
```

### Build برای Production
```bash
npm run build
```

## 🌐 Deploy

### GitHub Pages
مراحل کامل در فایل [GITHUB_PAGES_GUIDE.md](./GITHUB_PAGES_GUIDE.md)

### سایر گزینه‌ها
- **Vercel:** vercel.com
- **Netlify:** netlify.com
- **Firebase:** firebase.google.com

## 📱 تبدیل به APK

1. اپلیکیشن را deploy کنید
2. به [PWABuilder.com](https://www.pwabuilder.com) بروید  
3. URL deploy شده را وارد کنید
4. APK را دانلود کنید

## 🛠️ فناوری‌های استفاده شده

- **React 18** - UI Framework
- **TypeScript** - Type Safety  
- **Tailwind CSS v4** - Styling
- **ShadCN/UI** - Component Library
- **Lucide React** - Icons
- **PWA** - Progressive Web App

## 📂 ساختار پروژه

```
├── components/          # کامپوننت‌های React
│   ├── ui/             # کامپوننت‌های ShadCN
│   ├── Header.tsx      # هدر اپلیکیشن
│   ├── AuthModal.tsx   # مودال ورود
│   └── ...
├── public/             # فایل‌های Static
│   ├── manifest.json   # PWA Manifest
│   ├── sw.js          # Service Worker
│   └── icon.svg       # آیکون اپلیکیشن
├── styles/            # فایل‌های CSS
└── App.tsx           # کامپوننت اصلی

```

## 🎯 امکانات آینده

- [ ] پایگاه داده قطعات کامل‌تر
- [ ] سیستم امتیازدهی کاربران
- [ ] مقایسه قیمت‌ها
- [ ] پیشنهاد کانفیگ کامل
- [ ] اعلان‌های تخفیف

## 🤝 مشارکت

1. پروژه را Fork کنید
2. Branch جدید بسازید: `git checkout -b feature/amazing-feature`
3. تغییرات را commit کنید: `git commit -m 'Add amazing feature'`
4. Push کنید: `git push origin feature/amazing-feature`
5. Pull Request بسازید

## 📄 مجوز

این پروژه تحت مجوز MIT منتشر شده است.

## 📞 پشتیبانی

- 📧 **ایمیل:** support@partchecker.com
- 💬 **تلگرام:** @partchecker
- 🐛 **گزارش باگ:** [GitHub Issues](https://github.com/yourusername/part-checker/issues)

---

⭐ اگر این پروژه برایتان مفید بود، لطفاً ستاره بدهید!