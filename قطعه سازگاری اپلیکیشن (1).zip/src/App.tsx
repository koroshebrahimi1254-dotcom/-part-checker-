import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { Toaster } from "./components/ui/sonner";
import Header from "./components/Header";
import HeroSection from "./components/HeroSection";
import CompatibilityChecker from "./components/CompatibilityChecker";
import SuggestComponent from "./components/SuggestComponent";
import AuthModal from "./components/AuthModal";
import PWAInstaller from "./components/PWAInstaller";
import { CheckCircle, Package, Home } from "lucide-react";

export default function App() {
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [activeTab, setActiveTab] = useState("home");

  const handleLogin = (username: string) => {
    setCurrentUser(username);
  };

  const handleAuthClick = () => {
    if (currentUser) {
      setCurrentUser(null);
    } else {
      setShowAuthModal(true);
    }
  };

  const handleGetStarted = () => {
    setActiveTab("compatibility");
  };

  useEffect(() => {
    // Add manifest link to head
    const manifestLink = document.createElement('link');
    manifestLink.rel = 'manifest';
    manifestLink.href = '/manifest.json';
    document.head.appendChild(manifestLink);

    // Add theme color meta tag
    const themeColorMeta = document.createElement('meta');
    themeColorMeta.name = 'theme-color';
    themeColorMeta.content = '#2563eb';
    document.head.appendChild(themeColorMeta);

    // Add apple touch icon
    const appleTouchIcon = document.createElement('link');
    appleTouchIcon.rel = 'apple-touch-icon';
    appleTouchIcon.href = '/icon-192x192.png';
    document.head.appendChild(appleTouchIcon);

    // Add meta tags for mobile
    const viewportMeta = document.querySelector('meta[name="viewport"]');
    if (viewportMeta) {
      viewportMeta.setAttribute('content', 'width=device-width, initial-scale=1, user-scalable=no');
    }

    return () => {
      document.head.removeChild(manifestLink);
      document.head.removeChild(themeColorMeta);
      document.head.removeChild(appleTouchIcon);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      <Header onAuthClick={handleAuthClick} currentUser={currentUser} />
      
      <main>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="bg-white shadow-sm border-b">
            <div className="container mx-auto px-4">
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 bg-gray-100">
                <TabsTrigger value="home" className="flex items-center space-x-2 space-x-reverse">
                  <Home className="w-4 h-4" />
                  <span>خانه</span>
                </TabsTrigger>
                <TabsTrigger value="compatibility" className="flex items-center space-x-2 space-x-reverse">
                  <CheckCircle className="w-4 h-4" />
                  <span>بررسی سازگاری</span>
                </TabsTrigger>
                <TabsTrigger value="suggest" className="flex items-center space-x-2 space-x-reverse">
                  <Package className="w-4 h-4" />
                  <span>پیشنهاد قطعه</span>
                </TabsTrigger>
              </TabsList>
            </div>
          </div>

          <TabsContent value="home" className="mt-0">
            <HeroSection onGetStarted={handleGetStarted} />
            
            {/* آمار و اطلاعات */}
            <section className="py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">
                    چرا پارت چکر را انتخاب کنیم؟
                  </h2>
                  <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    ما با استفاده از پایگاه داده جامع قطعات و الگوریتم‌های پیشرفته، دقیق‌ترین بررسی سازگاری را ارائه می‌دهیم
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-blue-600 mb-2">+۵۰۰۰</div>
                    <p className="text-gray-600">قطعه در پایگاه داده</p>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-green-600 mb-2">۹۸٪</div>
                    <p className="text-gray-600">دقت تشخیص سازگاری</p>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-purple-600 mb-2">+۱۰ک</div>
                    <p className="text-gray-600">کاربر فعال</p>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-orange-600 mb-2">۲۴/۷</div>
                    <p className="text-gray-600">پشتیبانی آنلاین</p>
                  </div>
                </div>
              </div>
            </section>

            {/* اخبار و بروزرسانی‌ها */}
            <section className="py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">
                    آخرین بروزرسانی‌ها
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h3 className="font-semibold text-lg mb-3">پشتیبانی از پردازنده‌های جدید AMD</h3>
                    <p className="text-gray-600 mb-4">سری Ryzen 7000 به پایگاه داده اضافه شد</p>
                    <div className="text-sm text-gray-500">۲ روز پیش</div>
                  </div>
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h3 className="font-semibold text-lg mb-3">بهبود الگوریتم تشخیص</h3>
                    <p className="text-gray-600 mb-4">دقت بررسی منابع تغذیه افزایش یافت</p>
                    <div className="text-sm text-gray-500">۱ هفته پیش</div>
                  </div>
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h3 className="font-semibold text-lg mb-3">رابط کاربری جدید</h3>
                    <p className="text-gray-600 mb-4">طراحی بهبود یافته و سرعت بیشتر</p>
                    <div className="text-sm text-gray-500">۲ هفته پیش</div>
                  </div>
                </div>
              </div>
            </section>
          </TabsContent>

          <TabsContent value="compatibility" className="mt-0">
            <div className="container mx-auto px-4 py-8">
              <CompatibilityChecker />
            </div>
          </TabsContent>

          <TabsContent value="suggest" className="mt-0">
            <div className="container mx-auto px-4 py-8">
              <SuggestComponent />
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* فوتر */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold text-lg mb-4">پارت چکر</h3>
              <p className="text-gray-400">
                بهترین ابزار برای بررسی سازگاری قطعات کامپیوتر
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">خدمات</h4>
              <ul className="space-y-2 text-gray-400">
                <li>بررسی سازگاری</li>
                <li>پیشنهاد قطعه</li>
                <li>مشاوره تخصصی</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">پشتیبانی</h4>
              <ul className="space-y-2 text-gray-400">
                <li>راهنمای استفاده</li>
                <li>سوالات متداول</li>
                <li>تماس با ما</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">شبکه‌های اجتماعی</h4>
              <ul className="space-y-2 text-gray-400">
                <li>تلگرام</li>
                <li>اینستاگرام</li>
                <li>یوتیوب</li>
              </ul>
            </div>
          </div>
          <hr className="my-8 border-gray-800" />
          <div className="text-center text-gray-400">
            <p>&copy; ۱۴۰۳ پارت چکر. تمامی حقوق محفوظ است.</p>
          </div>
        </div>
      </footer>

      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)}
        onLogin={handleLogin}
      />
      
      <PWAInstaller />
      <Toaster position="top-center" />
    </div>
  );
}