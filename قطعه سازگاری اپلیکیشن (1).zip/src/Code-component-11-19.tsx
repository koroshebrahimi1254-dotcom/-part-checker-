# راهنمای Deploy با GitHub Pages - پارت چکر

## مرحله ۱: آماده‌سازی Repository

### ۱.۱ ایجاد Repository جدید
1. به [GitHub.com](https://github.com) بروید
2. روی **"New repository"** کلیک کنید
3. نام repository: `part-checker`
4. گزینه **"Public"** را انتخاب کنید
5. **"Create repository"** کنید

### ۱.۲ بروزرسانی package.json
در فایل `package.json` خط زیر را ویرایش کنید:
```json
"homepage": "https://USERNAME.github.io/part-checker"
```
`USERNAME` را با نام کاربری GitHub خود جایگزین کنید.

## مرحله ۲: آپلود کدها

### ۲.۱ ایجاد Git Repository محلی
```bash
git init
git add .
git commit -m "اولین commit - اپلیکیشن پارت چکر"
```

### ۲.۲ اتصال به GitHub
```bash
git remote add origin https://github.com/USERNAME/part-checker.git
git branch -M main
git push -u origin main
```

## مرحله ۳: فعال‌سازی GitHub Pages

1. **در repository خود به تب Settings بروید**
2. **در sidebar چپ روی "Pages" کلیک کنید**
3. **Source را روی "GitHub Actions" تنظیم کنید**
4. **Save کنید**

## مرحله ۴: منتظر Build شدن باشید

- GitHub Actions به صورت خودکار شروع می‌شود
- در تب **"Actions"** پیشرفت را ببینید
- معمولاً ۲-۵ دقیقه طول می‌کشد

## مرحله ۵: دسترسی به اپلیکیشن

✅ **اپلیکیشن شما در این آدرس آماده است:**
```
https://USERNAME.github.io/part-checker
```

## مرحله ۶: تبدیل به APK با PWABuilder

### ۶.۱ رفتن به PWABuilder
1. به [PWABuilder.com](https://www.pwabuilder.com) بروید
2. URL اپلیکیشن را وارد کنید:
   ```
   https://USERNAME.github.io/part-checker
   ```
3. روی **"Start"** کلیک کنید

### ۶.۲ تولید APK
1. PWABuilder اپلیکیشن را تحلیل می‌کند
2. روی **"Package For Stores"** کلیک کنید
3. **"Android"** را انتخاب کنید
4. روی **"Download Package"** کلیک کنید

### ۶.۳ نصب روی گوشی
1. **Settings > Security > Unknown Sources** را فعال کنید
2. فایل APK را در گوشی کپی کنید
3. روی فایل کلیک کرده و **Install** کنید

## نکات مهم

### 🔧 آپدیت کردن اپلیکیشن
برای بروزرسانی، فقط کافی است:
```bash
git add .
git commit -m "بروزرسانی جدید"
git push
```

### 🌐 URL های مهم
- **Repository:** `https://github.com/USERNAME/part-checker`
- **اپلیکیشن:** `https://USERNAME.github.io/part-checker`
- **Actions:** `https://github.com/USERNAME/part-checker/actions`

### 🚨 مشکلات رایج

**مشکل ۱: صفحه ۴۰۴**
- بررسی کنید که Pages فعال باشد
- منتظر بمانید تا Actions تمام شود

**مشکل ۲: CSS load نمی‌شود**
- مطمئن شوید `homepage` در package.json درست است
- Public URL را چک کنید

**مشکل ۳: Manifest خطا**
- بررسی کنید که manifest.json accessible باشد
- Path های آیکون‌ها را چک کنید

### 📱 تست PWA

برای تست کردن PWA قبل از PWABuilder:

1. **Chrome DevTools:**
   - F12 > Application > Manifest
   - Service Workers چک کنید

2. **Mobile Test:**
   - در Chrome موبایل باز کنید
   - گزینه "Add to Home Screen" باید نمایش داده شود

## مثال کامل

اگر نام کاربری GitHub شما `ali123` است:

1. **Repository URL:** `https://github.com/ali123/part-checker`
2. **اپلیکیشن URL:** `https://ali123.github.io/part-checker`
3. **Package.json homepage:** `"https://ali123.github.io/part-checker"`

---

✨ **بعد از deploy، URL اپلیکیشن را به PWABuilder.com بدهید تا APK بسازید!**