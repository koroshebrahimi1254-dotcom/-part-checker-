# راهنمای Deploy و تبدیل به APK - پارت چکر

## مرحله ۱: Deploy کردن اپلیکیشن

برای استفاده از PWABuilder.com، ابتدا باید اپلیکیشن را روی یک سرور آنلاین قرار دهید:

### گزینه ۱: Vercel (توصیه شده)
1. به سایت vercel.com بروید
2. با GitHub اکانت خود وارد شوید
3. پروژه را به GitHub آپلود کنید
4. در Vercel روی "Import Project" کلیک کنید
5. Repository خود را انتخاب کنید
6. Build Command: `npm run build`
7. Output Directory: `build`
8. Deploy کنید

### گزینه ۲: Netlify
1. به سایت netlify.com بروید
2. "Sites" > "Add new site" > "Deploy manually"
3. فولدر build شده پروژه را drag & drop کنید
4. یا از GitHub connect کنید

### گزینه ۳: GitHub Pages
1. پروژه را در GitHub قرار دهید
2. Settings > Pages
3. Source: Deploy from a branch
4. Branch: main
5. Folder: /build

## مرحله ۲: استفاده از PWABuilder

پس از deploy:

1. **به PWABuilder بروید:**
   - سایت: https://www.pwabuilder.com

2. **URL اپلیکیشن را وارد کنید:**
   - مثال: `https://part-checker.vercel.app`
   - روی "Start" کلیک کنید

3. **بررسی PWA:**
   - PWABuilder اپلیکیشن شما را تحلیل می‌کند
   - نشان می‌دهد چه چیزهایی برای PWA نیاز دارید

4. **تولید APK:**
   - روی "Package For Stores" کلیک کنید
   - "Android" را انتخاب کنید
   - "Download Package" را کلیک کنید

## مرحله ۳: نصب APK روی اندروید

1. **فعال کردن منابع نامعلوم:**
   - Settings > Security > Unknown Sources ✅

2. **نصب APK:**
   - فایل دانلود شده را روی گوشی کپی کنید
   - روی فایل APK کلیک کنید
   - "Install" را انتخاب کنید

## گزینه‌های جایگزین

### Capacitor (پیشرفته)
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "پارت چکر" "com.partchecker.app"
npx cap add android
npx cap copy
npx cap open android
```

### Cordova
```bash
npm install -g cordova
cordova create PartChecker com.partchecker.app "پارت چکر"
cd PartChecker
cordova platform add android
cordova build android
```

### سرویس‌های آنلاین دیگر
- **AppMySite:** appmysite.com
- **Appy Pie:** appypie.com  
- **AppsGeyser:** appsgeyser.com
- **WebViewGold:** webviewgold.com

## مشکلات رایج و حل آن‌ها

### مشکل ۱: Manifest یافت نشد
- مطمئن شوید `/public/manifest.json` موجود است
- بررسی کنید که سرور manifest را serve می‌کند

### مشکل ۲: Service Worker کار نمی‌کند  
- مطمئن شوید `/public/sw.js` موجود است
- بررسی کنید که HTTPS فعال است

### مشکل ۳: آیکون‌ها نمایش نمی‌دهند
- مطمئن شوید `/public/icon.svg` موجود است
- فرمت آیکون‌ها باید صحیح باشد

## بررسی PWA

برای تست PWA بودن اپلیکیشن:

1. **Chrome DevTools:**
   - F12 > Application > Manifest
   - Service Workers بررسی کنید

2. **Lighthouse:**
   - F12 > Lighthouse > PWA audit

3. **PWA Testing Tools:**
   - web.dev/measure
   - webhint.io

## نکات مهم

- ✅ اپلیکیشن باید HTTPS باشد
- ✅ Manifest.json باید معتبر باشد  
- ✅ Service Worker باید نصب شود
- ✅ آیکون‌های مناسب باید موجود باشد
- ✅ Start URL باید کار کند

## پشتیبانی

اگر مشکلی داشتید:
- مستندات PWABuilder را بخوانید
- در GitHub Issues سوال بپرسید
- از Discord community PWABuilder استفاده کنید

---

**نکته:** پس از deploy، لینک اپلیکیشن شما را به PWABuilder.com بدهید تا APK تولید شود!