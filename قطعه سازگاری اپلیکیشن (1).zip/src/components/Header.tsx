import { Button } from "./ui/button";
import { UserCircle, Cpu, Zap } from "lucide-react";

interface HeaderProps {
  onAuthClick: () => void;
  currentUser: string | null;
}

export default function Header({ onAuthClick, currentUser }: HeaderProps) {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-white/20 p-3 rounded-lg">
              <Cpu className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">پارت چکر</h1>
              <p className="text-blue-100">سازگاری قطعات کامپیوتر</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="flex items-center space-x-2 space-x-reverse bg-white/10 px-4 py-2 rounded-lg">
              <Zap className="w-5 h-5 text-yellow-300" />
              <span>بررسی هوشمند سازگاری</span>
            </div>
            
            <Button 
              onClick={onAuthClick}
              variant="secondary"
              className="flex items-center space-x-2 space-x-reverse"
            >
              <UserCircle className="w-5 h-5" />
              <span>{currentUser || "ورود / ثبت نام"}</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}