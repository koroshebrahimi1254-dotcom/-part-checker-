import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { CheckCircle, XCircle, AlertTriangle, Zap, HardDrive, MemoryStick, Monitor } from "lucide-react";

// داده‌های نمونه برای قطعات کامپیوتر
const components = {
  motherboard: [
    { id: "mb1", name: "ASUS ROG Strix B550-F", socket: "AM4", chipset: "B550", memorySupport: "DDR4", maxMemory: 128 },
    { id: "mb2", name: "MSI Z690 Gaming Edge", socket: "LGA1700", chipset: "Z690", memorySupport: "DDR4/DDR5", maxMemory: 128 },
    { id: "mb3", name: "Gigabyte B450 Gaming X", socket: "AM4", chipset: "B450", memorySupport: "DDR4", maxMemory: 64 }
  ],
  cpu: [
    { id: "cpu1", name: "AMD Ryzen 5 5600X", socket: "AM4", cores: 6, threads: 12, baseClock: 3.7, power: 65 },
    { id: "cpu2", name: "Intel Core i5-12600K", socket: "LGA1700", cores: 10, threads: 16, baseClock: 3.7, power: 125 },
    { id: "cpu3", name: "AMD Ryzen 7 5800X", socket: "AM4", cores: 8, threads: 16, baseClock: 3.8, power: 105 }
  ],
  ram: [
    { id: "ram1", name: "Corsair Vengeance LPX 16GB", type: "DDR4", speed: 3200, capacity: 16, voltage: 1.35 },
    { id: "ram2", name: "G.Skill Trident Z5 32GB", type: "DDR5", speed: 5600, capacity: 32, voltage: 1.25 },
    { id: "ram3", name: "Kingston Fury Beast 8GB", type: "DDR4", speed: 2666, capacity: 8, voltage: 1.2 }
  ],
  gpu: [
    { id: "gpu1", name: "NVIDIA RTX 4070", power: 200, length: 261, slots: 2.5, vram: 12 },
    { id: "gpu2", name: "AMD RX 7800 XT", power: 263, length: 276, slots: 2.5, vram: 16 },
    { id: "gpu3", name: "NVIDIA GTX 1660 Super", power: 125, length: 229, slots: 2, vram: 6 }
  ]
};

interface SelectedComponents {
  motherboard: string;
  cpu: string;
  ram: string;
  gpu: string;
}

export default function CompatibilityChecker() {
  const [selectedComponents, setSelectedComponents] = useState<SelectedComponents>({
    motherboard: "",
    cpu: "",
    ram: "",
    gpu: ""
  });
  const [checkResult, setCheckResult] = useState<any>(null);

  const handleComponentChange = (type: keyof SelectedComponents, value: string) => {
    setSelectedComponents(prev => ({ ...prev, [type]: value }));
    setCheckResult(null);
  };

  const checkCompatibility = () => {
    const results = [];
    
    if (selectedComponents.motherboard && selectedComponents.cpu) {
      const mb = components.motherboard.find(m => m.id === selectedComponents.motherboard);
      const cpu = components.cpu.find(c => c.id === selectedComponents.cpu);
      
      if (mb && cpu) {
        if (mb.socket === cpu.socket) {
          results.push({ 
            type: "success", 
            message: `پردازنده با مادربرد سازگار است (سوکت ${mb.socket})`,
            icon: CheckCircle 
          });
        } else {
          results.push({ 
            type: "error", 
            message: `پردازنده با مادربرد سازگار نیست! (سوکت ${cpu.socket} vs ${mb.socket})`,
            icon: XCircle 
          });
        }
      }
    }

    if (selectedComponents.motherboard && selectedComponents.ram) {
      const mb = components.motherboard.find(m => m.id === selectedComponents.motherboard);
      const ram = components.ram.find(r => r.id === selectedComponents.ram);
      
      if (mb && ram) {
        if (mb.memorySupport.includes(ram.type)) {
          results.push({ 
            type: "success", 
            message: `رم با مادربرد سازگار است (${ram.type})`,
            icon: CheckCircle 
          });
        } else {
          results.push({ 
            type: "error", 
            message: `رم با مادربرد سازگار نیست! (${ram.type} پشتیبانی نمی‌شود)`,
            icon: XCircle 
          });
        }
      }
    }

    if (selectedComponents.gpu) {
      const gpu = components.gpu.find(g => g.id === selectedComponents.gpu);
      if (gpu) {
        if (gpu.power > 250) {
          results.push({ 
            type: "warning", 
            message: `کارت گرافیک مصرف بالایی دارد (${gpu.power}W) - منبع تغذیه قوی لازم است`,
            icon: AlertTriangle 
          });
        } else {
          results.push({ 
            type: "success", 
            message: `مصرف برق کارت گرافیک مناسب است (${gpu.power}W)`,
            icon: CheckCircle 
          });
        }
      }
    }

    setCheckResult(results);
  };

  const getStatusColor = (type: string) => {
    switch (type) {
      case "success": return "text-green-600";
      case "error": return "text-red-600";
      case "warning": return "text-yellow-600";
      default: return "text-gray-600";
    }
  };

  const getStatusBadge = (type: string) => {
    switch (type) {
      case "success": return "bg-green-100 text-green-800";
      case "error": return "bg-red-100 text-red-800";
      case "warning": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-3 space-x-reverse">
            <Zap className="w-6 h-6 text-blue-600" />
            <span>بررسی سازگاری قطعات</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* انتخاب مادربرد */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 space-x-reverse">
                <HardDrive className="w-4 h-4" />
                <span>مادربرد</span>
              </label>
              <Select value={selectedComponents.motherboard} onValueChange={(value) => handleComponentChange("motherboard", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب مادربرد" />
                </SelectTrigger>
                <SelectContent>
                  {components.motherboard.map(mb => (
                    <SelectItem key={mb.id} value={mb.id}>
                      {mb.name} ({mb.socket})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* انتخاب پردازنده */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 space-x-reverse">
                <Zap className="w-4 h-4" />
                <span>پردازنده</span>
              </label>
              <Select value={selectedComponents.cpu} onValueChange={(value) => handleComponentChange("cpu", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب پردازنده" />
                </SelectTrigger>
                <SelectContent>
                  {components.cpu.map(cpu => (
                    <SelectItem key={cpu.id} value={cpu.id}>
                      {cpu.name} ({cpu.socket})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* انتخاب رم */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 space-x-reverse">
                <MemoryStick className="w-4 h-4" />
                <span>حافظه رم</span>
              </label>
              <Select value={selectedComponents.ram} onValueChange={(value) => handleComponentChange("ram", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب رم" />
                </SelectTrigger>
                <SelectContent>
                  {components.ram.map(ram => (
                    <SelectItem key={ram.id} value={ram.id}>
                      {ram.name} ({ram.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* انتخاب کارت گرافیک */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 space-x-reverse">
                <Monitor className="w-4 h-4" />
                <span>کارت گرافیک</span>
              </label>
              <Select value={selectedComponents.gpu} onValueChange={(value) => handleComponentChange("gpu", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب کارت گرافیک" />
                </SelectTrigger>
                <SelectContent>
                  {components.gpu.map(gpu => (
                    <SelectItem key={gpu.id} value={gpu.id}>
                      {gpu.name} ({gpu.power}W)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={checkCompatibility} 
            className="w-full" 
            disabled={!selectedComponents.motherboard || !selectedComponents.cpu}
          >
            بررسی سازگاری
          </Button>

          {/* نتایج بررسی */}
          {checkResult && (
            <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-semibold">نتایج بررسی:</h3>
              {checkResult.map((result: any, index: number) => (
                <div key={index} className="flex items-start space-x-3 space-x-reverse">
                  <result.icon className={`w-5 h-5 mt-0.5 ${getStatusColor(result.type)}`} />
                  <div className="flex-1">
                    <p className="text-sm">{result.message}</p>
                    <Badge className={`text-xs mt-1 ${getStatusBadge(result.type)}`}>
                      {result.type === "success" && "سازگار"}
                      {result.type === "error" && "ناسازگار"}
                      {result.type === "warning" && "هشدار"}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}