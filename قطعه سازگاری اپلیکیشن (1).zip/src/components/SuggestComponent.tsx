import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Label } from "./ui/label";
import { PlusCircle, Star, ThumbsUp, Package, Send } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ComponentSuggestion {
  id: string;
  name: string;
  type: string;
  description: string;
  specs: string;
  price: string;
  submittedBy: string;
  rating: number;
  votes: number;
}

const suggestedComponents: ComponentSuggestion[] = [
  {
    id: "1",
    name: "AMD Ryzen 7 7800X3D",
    type: "cpu",
    description: "پردازنده‌ای با کارایی فوق‌العاده برای گیمر ها",
    specs: "8 Core, 16 Thread, AM5 Socket",
    price: "۲۵,۰۰۰,۰۰۰ تومان",
    submittedBy: "علی محمدی",
    rating: 4.8,
    votes: 124
  },
  {
    id: "2",
    name: "ASUS TUF Gaming RTX 4080",
    type: "gpu",
    description: "کارت گرافیک قدرتمند با سیستم خنک‌کننده عالی",
    specs: "16GB GDDR6X, Ray Tracing, DLSS 3.0",
    price: "۴۵,۰۰۰,۰۰۰ تومان",
    submittedBy: "مریم احمدی",
    rating: 4.9,
    votes: 89
  },
  {
    id: "3",
    name: "Samsung 980 PRO 2TB",
    type: "storage",
    description: "SSD سریع و قابل اعتماد برای بارگذاری سریع",
    specs: "NVMe M.2, 7000MB/s Read Speed",
    price: "۸,۵۰۰,۰۰۰ تومان",
    submittedBy: "رضا کریمی",
    rating: 4.7,
    votes: 156
  }
];

export default function SuggestComponent() {
  const [suggestions, setSuggestions] = useState<ComponentSuggestion[]>(suggestedComponents);
  const [newSuggestion, setNewSuggestion] = useState({
    name: "",
    type: "",
    description: "",
    specs: "",
    price: ""
  });
  const [showForm, setShowForm] = useState(false);

  const handleSubmitSuggestion = (e: React.FormEvent) => {
    e.preventDefault();
    
    const suggestion: ComponentSuggestion = {
      id: Date.now().toString(),
      ...newSuggestion,
      submittedBy: "شما",
      rating: 0,
      votes: 0
    };

    setSuggestions(prev => [suggestion, ...prev]);
    setNewSuggestion({
      name: "",
      type: "",
      description: "",
      specs: "",
      price: ""
    });
    setShowForm(false);
    toast.success("قطعه پیشنهادی شما با موفقیت ثبت شد!");
  };

  const handleVote = (id: string) => {
    setSuggestions(prev => prev.map(item => 
      item.id === id 
        ? { ...item, votes: item.votes + 1, rating: Math.min(item.rating + 0.1, 5) }
        : item
    ));
    toast.success("رأی شما ثبت شد!");
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      cpu: "پردازنده",
      gpu: "کارت گرافیک", 
      motherboard: "مادربرد",
      ram: "حافظه رم",
      storage: "حافظه ذخیره‌سازی",
      psu: "منبع تغذیه",
      case: "کیس",
      cooler: "خنک‌کننده"
    };
    return labels[type] || type;
  };

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      cpu: "bg-blue-100 text-blue-800",
      gpu: "bg-green-100 text-green-800",
      motherboard: "bg-purple-100 text-purple-800",
      ram: "bg-yellow-100 text-yellow-800",
      storage: "bg-orange-100 text-orange-800",
      psu: "bg-red-100 text-red-800",
      case: "bg-gray-100 text-gray-800",
      cooler: "bg-cyan-100 text-cyan-800"
    };
    return colors[type] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-3 space-x-reverse">
              <Package className="w-6 h-6 text-purple-600" />
              <span>پیشنهادات قطعات</span>
            </CardTitle>
            <Button 
              onClick={() => setShowForm(!showForm)}
              className="flex items-center space-x-2 space-x-reverse"
            >
              <PlusCircle className="w-4 h-4" />
              <span>پیشنهاد جدید</span>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* فرم پیشنهاد جدید */}
          {showForm && (
            <form onSubmit={handleSubmitSuggestion} className="space-y-4 p-4 bg-gray-50 rounded-lg mb-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="component-name">نام قطعه</Label>
                  <Input
                    id="component-name"
                    placeholder="مثال: AMD Ryzen 9 7950X"
                    value={newSuggestion.name}
                    onChange={(e) => setNewSuggestion(prev => ({ ...prev, name: e.target.value }))}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="component-type">نوع قطعه</Label>
                  <Select value={newSuggestion.type} onValueChange={(value) => setNewSuggestion(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب نوع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cpu">پردازنده</SelectItem>
                      <SelectItem value="gpu">کارت گرافیک</SelectItem>
                      <SelectItem value="motherboard">مادربرد</SelectItem>
                      <SelectItem value="ram">حافظه رم</SelectItem>
                      <SelectItem value="storage">حافظه ذخیره‌سازی</SelectItem>
                      <SelectItem value="psu">منبع تغذیه</SelectItem>
                      <SelectItem value="case">کیس</SelectItem>
                      <SelectItem value="cooler">خنک‌کننده</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="component-specs">مشخصات فنی</Label>
                <Input
                  id="component-specs"
                  placeholder="مثال: 16 Core, 32 Thread, AM5 Socket, 4.5GHz Boost"
                  value={newSuggestion.specs}
                  onChange={(e) => setNewSuggestion(prev => ({ ...prev, specs: e.target.value }))}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="component-description">توضیحات</Label>
                <Textarea
                  id="component-description"
                  placeholder="چرا این قطعه را پیشنهاد می‌دهید؟"
                  value={newSuggestion.description}
                  onChange={(e) => setNewSuggestion(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="component-price">قیمت تقریبی</Label>
                <Input
                  id="component-price"
                  placeholder="مثال: ۱۵,۰۰۰,۰۰۰ تومان"
                  value={newSuggestion.price}
                  onChange={(e) => setNewSuggestion(prev => ({ ...prev, price: e.target.value }))}
                />
              </div>
              
              <div className="flex space-x-3 space-x-reverse">
                <Button type="submit" className="flex items-center space-x-2 space-x-reverse">
                  <Send className="w-4 h-4" />
                  <span>ارسال پیشنهاد</span>
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  انصراف
                </Button>
              </div>
            </form>
          )}

          {/* لیست پیشنهادات */}
          <div className="space-y-4">
            {suggestions.map((suggestion) => (
              <Card key={suggestion.id} className="border border-gray-200 hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 space-x-reverse mb-2">
                        <h3 className="font-semibold">{suggestion.name}</h3>
                        <Badge className={getTypeColor(suggestion.type)}>
                          {getTypeLabel(suggestion.type)}
                        </Badge>
                      </div>
                      
                      <p className="text-gray-600 text-sm mb-2">{suggestion.description}</p>
                      <p className="text-gray-700 text-sm mb-2"><strong>مشخصات:</strong> {suggestion.specs}</p>
                      {suggestion.price && (
                        <p className="text-green-600 font-semibold text-sm mb-2">{suggestion.price}</p>
                      )}
                      
                      <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-500">
                        <span>پیشنهاد شده توسط: {suggestion.submittedBy}</span>
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span>{suggestion.rating.toFixed(1)}</span>
                        </div>
                        <span>{suggestion.votes} رأی</span>
                      </div>
                    </div>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleVote(suggestion.id)}
                      className="flex items-center space-x-1 space-x-reverse"
                    >
                      <ThumbsUp className="w-4 h-4" />
                      <span>مفید</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}