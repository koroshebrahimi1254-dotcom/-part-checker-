import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Cpu, Shield, Users, Zap, Smartphone } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HeroSectionProps {
  onGetStarted: () => void;
}

export default function HeroSection({ onGetStarted }: HeroSectionProps) {
  const features = [
    {
      icon: Shield,
      title: "بررسی دقیق سازگاری",
      description: "سیستم پیشرفته تشخیص ناسازگاری قطعات"
    },
    {
      icon: Users,
      title: "پیشنهادات جامعه",
      description: "قطعات پیشنهادی از تجربه کاربران واقعی"
    },
    {
      icon: Zap,
      title: "سرعت بالا",
      description: "بررسی فوری و نتایج دقیق در چند ثانیه"
    },
    {
      icon: Smartphone,
      title: "قابل نصب روی موبایل",
      description: "دسترسی آفلاین و استفاده آسان روی گوشی"
    }
  ];

  return (
    <div className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* قسمت متن */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                پارت چکر
              </h1>
              <h2 className="text-xl lg:text-2xl text-gray-700">
                بررسی هوشمند سازگاری قطعات کامپیوتر
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                دیگر نگران سازگاری قطعات کامپیوترتان نباشید! سیستم ما به صورت هوشمند تمام جنبه‌های فنی را بررسی کرده و بهترین ترکیب را برای شما پیشنهاد می‌دهد.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                onClick={onGetStarted}
                className="text-lg px-8 py-3"
              >
                شروع بررسی سازگاری
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="text-lg px-8 py-3"
              >
                مشاهده راهنما
              </Button>
            </div>

            {/* ویژگی‌ها */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4 gap-4">
              {features.map((feature, index) => (
                <Card key={index} className="border-none shadow-sm bg-white/50 backdrop-blur-sm">
                  <CardContent className="p-4 text-center">
                    <feature.icon className="w-8 h-8 mx-auto mb-3 text-blue-600" />
                    <h3 className="font-semibold mb-2">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* قسمت تصویر */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-2xl shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1658671141384-c4317684a1a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBjb21wdXRlciUyMHNldHVwJTIwUkdCfGVufDF8fHx8MTc1NzQ4NjI0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Computer Gaming Setup"
                className="w-full h-80 lg:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>

            {/* کارت‌های شناور */}
            <div className="absolute -top-6 -right-6 bg-white rounded-lg shadow-lg p-4 max-w-xs">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="bg-green-100 p-2 rounded-lg">
                  <Cpu className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-sm">سازگاری ۱۰۰٪</p>
                  <p className="text-xs text-gray-600">قطعات شما کاملاً سازگار هستند</p>
                </div>
              </div>
            </div>

            <div className="absolute -bottom-6 -left-6 bg-white rounded-lg shadow-lg p-4 max-w-xs">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="font-semibold text-sm">+۱۰,۰۰۰ کاربر</p>
                  <p className="text-xs text-gray-600">به پارت چکر اعتماد کرده‌اند</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}